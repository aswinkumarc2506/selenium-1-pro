package methodes;

public class _8_task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
